# Signal: onboarding playbook

Signal turns scattered client and internal requests into one ranked queue, so you always know what to work on next. No technical setup or coding is required.

## What Signal is

Signal is a private web page that keeps a running list of every request coming in from clients and from people inside the company, and works out which one you should tackle next.

It solves a specific problem: in a startup, requests arrive everywhere at once (email, Slack, conversations) and there's no ops team to sort them. Signal replaces that scramble with one queue you can trust.

## What it does, in practice

- **Logs every request:** who asked, what for, when, and whether it's a client or internal.
- **Scores and ranks automatically:** each request gets a score out of 10 based on who asked, effort, value, deadline and account health.
- **Builds your day:** "Today's plan" fits the highest-priority work into the hours you actually have.
- **Watches for risk:** flags clients waiting too long for a reply, and anything stuck waiting on someone else.

## Getting the most out of it

1. **Start your day on the Queue tab.** The highest-priority request sits at the top. That's always what you do first.
2. **Check the alerts at the top.** They catch clients waiting for a reply and follow-ups due today.
3. **Work down the ranked list, not your inbox.** Trust the ranking instead of re-deciding priority every morning.
4. **Use "Today's plan" to set expectations.** If it warns you're over capacity, use that to push back or renegotiate a deadline.
5. **Click "Replied" as soon as you acknowledge a client**, even before the work is finished. The button greys out to show it's done.
6. **Move blocked work to "Waiting on someone"** so it doesn't push down work you can actually do.
7. **Keep account health scores current** in the Clients tab. At-risk accounts rank higher automatically.

## Getting it operational

1. Open `index.html`, or the GitHub Pages link if it's published. Bookmark it.
2. Add your client accounts in the Clients tab with ARR, renewal date and health score.
3. Add your first few requests with "Add request".
4. Adjust Settings if needed. Defaults: 6 focus hours a day, a 2-hour reply window, £50,000 key-account threshold, 90-day renewal window.

## Scaling it further

| Upgrade | Why it's worth it |
| --- | --- |
| Auto-capture from email and Slack | Removes the last manual step, so no request is missed |
| Team view | Lets a manager see workload across the team and spot overload early |
| CRM sync | Keeps ARR, renewal and health data accurate without manual upkeep |
| Response-time reporting | Turns reply data into evidence of service quality for reviews |
| Shared account history | Gives a new AM instant context when an account changes hands |
